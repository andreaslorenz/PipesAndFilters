package itb04.sa.teamb.pipesfilters;

public class NullReceivedException extends Exception {


}
