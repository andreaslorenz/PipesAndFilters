package itb04.sa.teamb.pipesfilters;

public interface IOable<in, out> extends Readable<out>, Writeable<in> {

}
